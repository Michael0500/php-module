--TEST--
MQCONNX передаёт MQAIR OCSPResponderURL локальному OCSP-ответчику
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
foreach (['MQSERIES_TEST_QM', 'MQSERIES_TEST_OCSP_CHANNEL', 'MQSERIES_TEST_TLS_CIPHER', 'MQSERIES_TEST_TLS_KEY_REPOSITORY', 'MQSERIES_TEST_OCSP_URL', 'MQSERIES_TEST_OCSP_LOG'] as $name) {
    if (!getenv($name)) die("skip задайте $name для OCSP-теста");
}
?>
--FILE--
<?php
$options = [
    'MQCD' => [
        'Version' => MQSERIES_MQCD_VERSION_7,
        'ChannelName' => getenv('MQSERIES_TEST_OCSP_CHANNEL'),
        'ConnectionName' => 'qm(1414)',
        'TransportType' => MQSERIES_MQXPT_TCP,
        'SSLCipherSpec' => getenv('MQSERIES_TEST_TLS_CIPHER'),
    ],
    'MQSCO' => [
        'Version' => MQSERIES_MQSCO_VERSION_2,
        'KeyRepository' => getenv('MQSERIES_TEST_TLS_KEY_REPOSITORY'),
        'MQAIR' => [
            'Version' => MQSERIES_MQAIR_VERSION_2,
            'AuthInfoType' => MQSERIES_MQAIT_OCSP,
            'OCSPResponderURL' => getenv('MQSERIES_TEST_OCSP_URL'),
        ],
    ],
    'MQCSP' => [
        'UserId' => getenv('MQSERIES_TEST_USER'),
        'Password' => getenv('MQSERIES_TEST_PASSWORD'),
    ],
];
mqseries_connx(getenv('MQSERIES_TEST_QM'), $options, $conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка OCSP-подключения: $reason\n";
    return;
}
mqseries_disc($conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка отключения: $reason\n";
    return;
}
$log = file_get_contents(getenv('MQSERIES_TEST_OCSP_LOG'));
if ($log === false || strpos($log, 'OCSP Request Data') === false || strpos($log, 'Cert Status: good') === false) {
    echo "OCSP-ответчик не подтвердил действующий сертификат\n";
    return;
}
echo "OK\n";
?>
--EXPECT--
OK
