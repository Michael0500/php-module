--TEST--
MQSET изменяет INHIBIT_PUT выделенной очереди и восстанавливает его
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
if (!getenv('MQSERIES_TEST_QM') || !getenv('MQSERIES_TEST_SET_QUEUE')) {
    die('skip задайте MQSERIES_TEST_QM и MQSERIES_TEST_SET_QUEUE');
}
?>
--FILE--
<?php
$options = [];
$user = getenv('MQSERIES_TEST_USER');
$password = getenv('MQSERIES_TEST_PASSWORD');
if ($user !== false && $password !== false) {
    $options['MQCSP'] = ['UserId' => $user, 'Password' => $password];
}
mqseries_connx(getenv('MQSERIES_TEST_QM'), $options, $conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка подключения: $reason\n";
    return;
}

$od = ['ObjectName' => getenv('MQSERIES_TEST_SET_QUEUE')];
mqseries_open($conn, $od, MQSERIES_MQOO_INQUIRE | MQSERIES_MQOO_SET, $obj, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка открытия: $reason\n";
    mqseries_disc($conn, $cc, $reason);
    return;
}

$selector = [MQSERIES_MQIA_INHIBIT_PUT];
$values = [];
$chars = null;
mqseries_inq($conn, $obj, 1, $selector, 1, $values, 0, $chars, $cc, $reason);
$original = $values[0] ?? null;
if ($cc !== MQSERIES_MQCC_OK || !is_int($original)) {
    echo "Ошибка исходного MQINQ: $reason\n";
} else {
    $target = $original === 0 ? 1 : 0;
    $emptyChars = [];
    mqseries_set($conn, $obj, 1, $selector, 1, [$target], 0, $emptyChars, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK) {
        echo "Ошибка MQSET: $reason\n";
    } else {
        $values = [];
        $chars = null;
        mqseries_inq($conn, $obj, 1, $selector, 1, $values, 0, $chars, $cc, $reason);
        $changed = $cc === MQSERIES_MQCC_OK && ($values[0] ?? null) === $target;
        mqseries_set($conn, $obj, 1, $selector, 1, [$original], 0, $emptyChars, $cc, $reason);
        if ($cc !== MQSERIES_MQCC_OK) {
            echo "Ошибка восстановления MQSET: $reason\n";
        } else {
            $values = [];
            $chars = null;
            mqseries_inq($conn, $obj, 1, $selector, 1, $values, 0, $chars, $cc, $reason);
            if (!$changed || $cc !== MQSERIES_MQCC_OK || ($values[0] ?? null) !== $original) {
                echo "Атрибут INHIBIT_PUT не восстановлен\n";
            } else {
                echo "OK\n";
            }
        }
    }
}
mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
mqseries_disc($conn, $cc, $reason);
?>
--EXPECT--
OK
