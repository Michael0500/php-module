--TEST--
Повторные подключения, двоичные ресурсы и освобождение дескрипторов
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
if (!getenv('MQSERIES_TEST_QM') || !getenv('MQSERIES_TEST_QUEUE')) {
    die('skip задайте MQSERIES_TEST_QM и MQSERIES_TEST_QUEUE');
}
?>
--FILE--
<?php
for ($i = 0; $i < 10; $i++) {
    $options = [];
    if (getenv('MQSERIES_TEST_USER') !== false && getenv('MQSERIES_TEST_PASSWORD') !== false) {
        $options['MQCSP'] = [
            'UserId' => getenv('MQSERIES_TEST_USER'),
            'Password' => getenv('MQSERIES_TEST_PASSWORD'),
        ];
    }
    mqseries_connx(getenv('MQSERIES_TEST_QM'), $options, $conn, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK) {
        echo "Ошибка подключения $i: $reason\n";
        return;
    }
    $od = ['ObjectName' => getenv('MQSERIES_TEST_QUEUE')];
    mqseries_open($conn, $od, MQSERIES_MQOO_INPUT_AS_Q_DEF | MQSERIES_MQOO_OUTPUT, $obj, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK) {
        echo "Ошибка открытия $i: $reason\n";
        return;
    }
    $message = 'mqseries-lifecycle-' . getmypid() . '-' . $i;
    $md = ['Format' => MQSERIES_MQFMT_STRING];
    $pmo = [];
    mqseries_put($conn, $obj, $md, $pmo, $message, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK) {
        echo "Ошибка записи $i: $reason\n";
        return;
    }
    $md = [];
    $gmo = ['Options' => MQSERIES_MQGMO_NO_WAIT];
    mqseries_get($conn, $obj, $md, $gmo, 4096, $received, $length, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK || $received !== $message ||
        mqseries_bytes_val($md['CorrelId']) !== str_repeat("\0", 24)) {
        echo "Ошибка чтения $i: $reason\n";
        return;
    }
    unset($md, $gmo, $pmo, $received);
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK) {
        echo "Ошибка закрытия $i: $reason\n";
        return;
    }
    unset($obj);
    mqseries_disc($conn, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK) {
        echo "Ошибка отключения $i: $reason\n";
        return;
    }
    unset($conn);
    gc_collect_cycles();
}
echo "OK\n";
?>
--EXPECT--
OK
