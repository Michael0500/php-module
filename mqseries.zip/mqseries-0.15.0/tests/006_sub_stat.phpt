--TEST--
MQSUB принимает публикацию, MQSTAT учитывает тип соединения
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
if (!function_exists('mqseries_sub') || !function_exists('mqseries_stat')) {
    die('skip библиотека IBM MQ не поддерживает MQSUB/MQSTAT');
}
if (!getenv('MQSERIES_TEST_QM') || !getenv('MQSERIES_TEST_TOPIC')) {
    die('skip задайте MQSERIES_TEST_QM и MQSERIES_TEST_TOPIC');
}
?>
--FILE--
<?php
$options = [];
$user = getenv('MQSERIES_TEST_USER');
$password = getenv('MQSERIES_TEST_PASSWORD');
if ($user !== false && $password !== false) {
    $options['MQCSP'] = ['UserId' => $user, 'Password' => $password];
}
mqseries_connx(getenv('MQSERIES_TEST_QM'), $options, $conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка подключения: $reason\n";
    return;
}

$topicName = getenv('MQSERIES_TEST_TOPIC');
$topicString = 'mqseries/phpt/' . getmypid();
$sd = [
    'Options' => MQSERIES_MQSO_CREATE | MQSERIES_MQSO_NON_DURABLE | MQSERIES_MQSO_MANAGED,
    'ObjectName' => $topicName,
    'ObjectString' => $topicString,
];
$subscriptionQueue = null;
$subscription = null;
mqseries_sub($conn, $sd, $subscriptionQueue, $subscription, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка MQSUB: $reason\n";
    mqseries_disc($conn, $cc, $reason);
    return;
}

$status = [];
mqseries_stat($conn, MQSERIES_MQSTAT_TYPE_RECONNECTION, $status, $cc, $reason);
if (getenv('MQSERIES_LIB') === 'mqm') {
    // Состояние переподключения определено IBM MQ только для клиентского подключения.
    if ($cc !== MQSERIES_MQCC_FAILED || $reason !== MQSERIES_MQRC_ENVIRONMENT_ERROR) {
        echo "Ошибка проверки MQSTAT в серверном режиме: $reason\n";
    }
} elseif ($cc !== MQSERIES_MQCC_OK || !isset($status['CompCode'])) {
    echo "Ошибка MQSTAT в клиентском режиме: $reason\n";
}

$od = [
    'Version' => MQSERIES_MQOD_VERSION_4,
    'ObjectType' => MQSERIES_MQOT_TOPIC,
    'ObjectName' => $topicName,
    'ObjectString' => $topicString,
];
mqseries_open($conn, $od, MQSERIES_MQOO_OUTPUT, $publisher, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка открытия темы: $reason\n";
} else {
    $message = 'mqseries-sub-phpt-' . getmypid();
    $md = ['Format' => MQSERIES_MQFMT_STRING];
    $pmo = [];
    mqseries_put($conn, $publisher, $md, $pmo, $message, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK) {
        echo "Ошибка публикации: $reason\n";
    } else {
        $md = [];
        $gmo = ['Options' => MQSERIES_MQGMO_WAIT, 'WaitInterval' => 5000];
        mqseries_get($conn, $subscriptionQueue, $md, $gmo, 4096, $received, $length, $cc, $reason);
        if ($cc !== MQSERIES_MQCC_OK || $received !== $message || $length !== strlen($message)) {
            echo "Ошибка чтения подписки: $reason; подписка=" . ($sd['ResObjectString'] ?? '') . "; публикация=" . ($od['ResObjectString'] ?? '') . "\n";
        } else {
            echo "OK\n";
        }
    }
    mqseries_close($conn, $publisher, MQSERIES_MQCO_NONE, $cc, $reason);
}
mqseries_close($conn, $subscription, MQSERIES_MQCO_NONE, $cc, $reason);
mqseries_close($conn, $subscriptionQueue, MQSERIES_MQCO_NONE, $cc, $reason);
mqseries_disc($conn, $cc, $reason);
?>
--EXPECT--
OK
