--TEST--
Публичные функции и константы mqseries 0.16.0
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
?>
--FILE--
<?php
$version = phpversion('mqseries');
if ($version !== '0.16.0') {
    echo "Неверная версия модуля: $version\n";
}
$functions = [
    'back', 'begin', 'close', 'cmit', 'conn', 'connx', 'disc',
    'get', 'inq', 'open', 'put', 'put1', 'set', 'strerror', 'bytes_val',
];
foreach ($functions as $function) {
    if (!function_exists('mqseries_' . $function)) {
        echo "Нет функции: $function\n";
    }
}
foreach (['MQSERIES_MQCC_OK', 'MQSERIES_MQFMT_MD_EXTENSION'] as $constant) {
    if (!defined($constant)) {
        echo "Нет константы: $constant\n";
    }
}
echo "OK\n";
?>
--EXPECT--
OK
