--TEST--
MQBEGIN, MQBACK и MQCMIT в серверном режиме с реальным Queue Manager
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
if (!getenv('MQSERIES_TEST_QM') || !getenv('MQSERIES_TEST_TX_QUEUE')) {
    die('skip задайте MQSERIES_TEST_QM и MQSERIES_TEST_TX_QUEUE для server bindings');
}
?>
--FILE--
<?php
mqseries_conn(getenv('MQSERIES_TEST_QM'), $conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка локального подключения: $cc/$reason\n";
    return;
}

$od = ['ObjectName' => getenv('MQSERIES_TEST_TX_QUEUE')];
mqseries_open($conn, $od, MQSERIES_MQOO_INPUT_AS_Q_DEF | MQSERIES_MQOO_OUTPUT, $obj, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка открытия транзакционной очереди: $cc/$reason\n";
    mqseries_disc($conn, $cc, $reason);
    return;
}

function beginUnit($conn, $step) {
    $bo = [];
    mqseries_begin($conn, $bo, $cc, $reason);
    if ($cc === MQSERIES_MQCC_OK ||
        ($cc === MQSERIES_MQCC_WARNING && $reason === MQSERIES_MQRC_NO_EXTERNAL_PARTICIPANTS)) {
        return true;
    }
    echo "Ошибка MQBEGIN $step: $cc/$reason\n";
    return false;
}

$message = 'mqseries-tx-' . getmypid();
if (!beginUnit($conn, 'rollback')) {
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    mqseries_disc($conn, $cc, $reason);
    return;
}
$md = ['Format' => MQSERIES_MQFMT_STRING];
$pmo = ['Options' => MQSERIES_MQPMO_SYNCPOINT];
mqseries_put($conn, $obj, $md, $pmo, $message, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка транзакционной записи перед MQBACK: $cc/$reason\n";
    mqseries_back($conn, $cc, $reason);
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    mqseries_disc($conn, $cc, $reason);
    return;
}
mqseries_back($conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка MQBACK: $cc/$reason\n";
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    mqseries_disc($conn, $cc, $reason);
    return;
}

$md = [];
$gmo = ['Options' => MQSERIES_MQGMO_NO_WAIT];
mqseries_get($conn, $obj, $md, $gmo, 4096, $received, $length, $cc, $reason);
if ($cc !== MQSERIES_MQCC_FAILED || $reason !== MQSERIES_MQRC_NO_MSG_AVAILABLE) {
    echo "Сообщение осталось после MQBACK: $cc/$reason\n";
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    mqseries_disc($conn, $cc, $reason);
    return;
}

if (!beginUnit($conn, 'commit')) {
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    mqseries_disc($conn, $cc, $reason);
    return;
}
$md = ['Format' => MQSERIES_MQFMT_STRING];
$pmo = ['Options' => MQSERIES_MQPMO_SYNCPOINT];
mqseries_put($conn, $obj, $md, $pmo, $message, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка транзакционной записи перед MQCMIT: $cc/$reason\n";
    mqseries_back($conn, $cc, $reason);
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    mqseries_disc($conn, $cc, $reason);
    return;
}
mqseries_cmit($conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка MQCMIT: $cc/$reason\n";
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    mqseries_disc($conn, $cc, $reason);
    return;
}

$md = [];
$gmo = ['Options' => MQSERIES_MQGMO_NO_WAIT];
mqseries_get($conn, $obj, $md, $gmo, 4096, $received, $length, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK || $received !== $message) {
    echo "Ошибка чтения после MQCMIT: $cc/$reason\n";
} else {
    echo "OK\n";
}
mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
mqseries_disc($conn, $cc, $reason);
?>
--EXPECT--
OK
