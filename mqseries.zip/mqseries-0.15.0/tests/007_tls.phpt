--TEST--
MQCONNX устанавливает защищённое TLS-соединение через MQCD и MQSCO
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
foreach (['MQSERIES_TEST_QM', 'MQSERIES_TEST_TLS_CHANNEL', 'MQSERIES_TEST_TLS_CIPHER', 'MQSERIES_TEST_TLS_KEY_REPOSITORY'] as $name) {
    if (!getenv($name)) die("skip задайте $name для TLS-теста");
}
?>
--FILE--
<?php
$options = [
    'MQCD' => [
        'Version' => MQSERIES_MQCD_VERSION_7,
        'ChannelName' => getenv('MQSERIES_TEST_TLS_CHANNEL'),
        'ConnectionName' => 'qm(1414)',
        'TransportType' => MQSERIES_MQXPT_TCP,
        'SSLCipherSpec' => getenv('MQSERIES_TEST_TLS_CIPHER'),
    ],
    'MQSCO' => ['KeyRepository' => getenv('MQSERIES_TEST_TLS_KEY_REPOSITORY')],
    'MQCSP' => [
        'UserId' => getenv('MQSERIES_TEST_USER'),
        'Password' => getenv('MQSERIES_TEST_PASSWORD'),
    ],
];
mqseries_connx(getenv('MQSERIES_TEST_QM'), $options, $conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка TLS-подключения: $reason\n";
    return;
}
mqseries_disc($conn, $cc, $reason);
if ($cc === MQSERIES_MQCC_OK) echo "OK\n";
?>
--EXPECT--
OK
