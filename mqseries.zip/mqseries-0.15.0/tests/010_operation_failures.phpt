--TEST--
Ошибки MQOPEN, MQGET и неверного типа ресурса не повреждают соединение
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
if (!getenv('MQSERIES_TEST_QM') || !getenv('MQSERIES_TEST_QUEUE')) {
    die('skip задайте MQSERIES_TEST_QM и MQSERIES_TEST_QUEUE');
}
?>
--FILE--
<?php
$options = [];
if (getenv('MQSERIES_TEST_USER') !== false && getenv('MQSERIES_TEST_PASSWORD') !== false) {
    $options['MQCSP'] = [
        'UserId' => getenv('MQSERIES_TEST_USER'),
        'Password' => getenv('MQSERIES_TEST_PASSWORD'),
    ];
}
mqseries_connx(getenv('MQSERIES_TEST_QM'), $options, $conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка подключения: $reason\n";
    return;
}

$od = ['ObjectName' => 'MQSERIES.MISSING.QUEUE'];
$missing = null;
mqseries_open($conn, $od, MQSERIES_MQOO_INPUT_AS_Q_DEF, $missing, $cc, $reason);
if ($cc !== MQSERIES_MQCC_FAILED || $reason !== MQSERIES_MQRC_UNKNOWN_OBJECT_NAME || $missing !== null) {
    echo "Ошибка проверки отсутствующей очереди: $cc/$reason\n";
    mqseries_disc($conn, $cc, $reason);
    return;
}

$od = ['ObjectName' => getenv('MQSERIES_TEST_QUEUE')];
mqseries_open($conn, $od, MQSERIES_MQOO_INPUT_AS_Q_DEF, $obj, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка открытия рабочей очереди: $reason\n";
    mqseries_disc($conn, $cc, $reason);
    return;
}

$md = [];
$gmo = ['Options' => MQSERIES_MQGMO_NO_WAIT];
$buffer = 'не изменён';
$length = -1;
$cc = -1;
$reason = -1;
$result = @mqseries_get($conn, $obj, $md, $gmo, -1, $buffer, $length, $cc, $reason);
if ($result !== false || $buffer !== 'не изменён' || $length !== -1 || $cc !== -1 || $reason !== -1) {
    echo "Ошибка проверки отрицательной длины буфера\n";
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    mqseries_disc($conn, $cc, $reason);
    return;
}

try {
    $result = @mqseries_bytes_val($conn);
} catch (TypeError $error) {
    $result = false;
}
if ($result !== false) {
    echo "Ошибка проверки типа двоичного ресурса\n";
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    mqseries_disc($conn, $cc, $reason);
    return;
}

mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка закрытия рабочей очереди: $reason\n";
    mqseries_disc($conn, $cc, $reason);
    return;
}
mqseries_disc($conn, $cc, $reason);
echo $cc === MQSERIES_MQCC_OK ? "OK\n" : "Ошибка отключения: $reason\n";
?>
--EXPECT--
OK
