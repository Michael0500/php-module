--TEST--
Получение текста причины MQ без брокера
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
?>
--FILE--
<?php
$result = mqseries_strerror(MQSERIES_MQRC_NONE);
var_dump(is_string($result));
?>
--EXPECT--
bool(true)
