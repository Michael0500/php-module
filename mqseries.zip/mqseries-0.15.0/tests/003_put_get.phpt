--TEST--
Подключение к IBM MQ, запись и чтение сообщения
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
if (!getenv('MQSERIES_TEST_QM') || !getenv('MQSERIES_TEST_QUEUE')) {
    die('skip задайте MQSERIES_TEST_QM и MQSERIES_TEST_QUEUE для интеграционного теста');
}
?>
--FILE--
<?php
$qm = getenv('MQSERIES_TEST_QM');
$conn = null;
$user = getenv('MQSERIES_TEST_USER');
$password = getenv('MQSERIES_TEST_PASSWORD');
if ($user !== false && $password !== false) {
    $options = ['MQCSP' => ['UserId' => $user, 'Password' => $password]];
    mqseries_connx($qm, $options, $conn, $cc, $reason);
} else {
    mqseries_conn($qm, $conn, $cc, $reason);
}
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка подключения: $reason\n";
    return;
}

function checkQueue($conn, $queue) {
    $od = ['ObjectName' => $queue];
    $obj = null;
    mqseries_open($conn, $od, MQSERIES_MQOO_INPUT_AS_Q_DEF | MQSERIES_MQOO_OUTPUT, $obj, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK) {
        echo "Ошибка открытия $queue: $reason\n";
        return false;
    }
    $message = 'mqseries-phpt-' . $queue . '-' . getmypid();
    $md = ['Format' => MQSERIES_MQFMT_STRING];
    $pmo = [];
    mqseries_put($conn, $obj, $md, $pmo, $message, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK) {
        echo "Ошибка записи $queue: $reason\n";
        $ok = false;
    } else {
        $md = [];
        $gmo = ['Options' => MQSERIES_MQGMO_NO_WAIT];
        mqseries_get($conn, $obj, $md, $gmo, 4096, $received, $length, $cc, $reason);
        $ok = $cc === MQSERIES_MQCC_OK && $received === $message && $length === strlen($message);
        if (!$ok) echo "Ошибка чтения $queue: $reason\n";
    }
    mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
    return $ok;
}

$ok = checkQueue($conn, getenv('MQSERIES_TEST_QUEUE'));
$outQueue = getenv('MQSERIES_TEST_OUT_QUEUE');
if ($outQueue !== false && $outQueue !== '') {
    $ok = checkQueue($conn, $outQueue) && $ok;
}
mqseries_disc($conn, $cc, $reason);
if ($ok) echo "OK\n";
?>
--EXPECT--
OK
