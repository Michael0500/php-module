--TEST--
MQPUT1, MQINQ и чтение двоичного сообщения из выделенной очереди
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
if (!getenv('MQSERIES_TEST_QM') || !getenv('MQSERIES_TEST_QUEUE')) {
    die('skip задайте MQSERIES_TEST_QM и MQSERIES_TEST_QUEUE');
}
?>
--FILE--
<?php
$options = [];
$user = getenv('MQSERIES_TEST_USER');
$password = getenv('MQSERIES_TEST_PASSWORD');
if ($user !== false && $password !== false) {
    $options['MQCSP'] = ['UserId' => $user, 'Password' => $password];
}
mqseries_connx(getenv('MQSERIES_TEST_QM'), $options, $conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка подключения: $reason\n";
    return;
}

$queue = getenv('MQSERIES_TEST_QUEUE');
$od = ['ObjectName' => $queue];
$md = ['Format' => MQSERIES_MQFMT_STRING];
$pmo = [];
$message = "mqseries-phpt-\0binary-" . getmypid();
mqseries_put1($conn, $od, $md, $pmo, $message, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка MQPUT1: $reason\n";
    mqseries_disc($conn, $cc, $reason);
    return;
}

$od = ['ObjectName' => $queue];
mqseries_open($conn, $od, MQSERIES_MQOO_INPUT_AS_Q_DEF | MQSERIES_MQOO_INQUIRE, $obj, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK) {
    echo "Ошибка открытия очереди: $reason\n";
    mqseries_disc($conn, $cc, $reason);
    return;
}

$attrs = [];
$chars = null;
mqseries_inq($conn, $obj, 1, [MQSERIES_MQIA_CURRENT_Q_DEPTH], 1, $attrs, 0, $chars, $cc, $reason);
if ($cc !== MQSERIES_MQCC_OK || !isset($attrs[0]) || $attrs[0] < 1) {
    echo "Ошибка MQINQ: $reason\n";
} else {
    $md = [];
    $gmo = ['Options' => MQSERIES_MQGMO_NO_WAIT];
    mqseries_get($conn, $obj, $md, $gmo, 4096, $received, $length, $cc, $reason);
    if ($cc !== MQSERIES_MQCC_OK || $received !== $message || $length !== strlen($message)) {
        echo "Ошибка двоичного MQGET: $reason\n";
    } elseif (!isset($md['CorrelId']) || mqseries_bytes_val($md['CorrelId']) !== str_repeat("\0", 24)) {
        echo "Ошибка двоичного CorrelId\n";
    } else {
        echo "OK\n";
    }
}
mqseries_close($conn, $obj, MQSERIES_MQCO_NONE, $cc, $reason);
mqseries_disc($conn, $cc, $reason);
?>
--EXPECT--
OK
