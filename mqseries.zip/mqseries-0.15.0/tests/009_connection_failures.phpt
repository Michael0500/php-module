--TEST--
Отказ подключения с неверными учётными данными и неизвестным менеджером
--SKIPIF--
<?php
if (!extension_loaded('mqseries')) die('skip расширение mqseries не загружено');
if (!getenv('MQSERIES_TEST_QM') || !getenv('MQSERIES_TEST_USER') || !getenv('MQSERIES_TEST_PASSWORD')) {
    die('skip задайте параметры подключения к тестовому менеджеру');
}
?>
--FILE--
<?php
$options = ['MQCSP' => [
    'UserId' => getenv('MQSERIES_TEST_USER'),
    'Password' => getenv('MQSERIES_TEST_PASSWORD') . '-wrong',
]];
$conn = null;
mqseries_connx(getenv('MQSERIES_TEST_QM'), $options, $conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_FAILED || $reason !== MQSERIES_MQRC_NOT_AUTHORIZED || $conn !== null) {
    echo "Ошибка проверки неверного пароля: $cc/$reason\n";
    return;
}

$options['MQCSP']['Password'] = getenv('MQSERIES_TEST_PASSWORD');
mqseries_connx('MQSERIES_UNKNOWN_QM', $options, $conn, $cc, $reason);
if ($cc !== MQSERIES_MQCC_FAILED || $reason === MQSERIES_MQRC_NONE || $conn !== null) {
    echo "Ошибка проверки неизвестного менеджера: $cc/$reason\n";
    return;
}

echo "OK\n";
?>
--EXPECT--
OK
