dnl Конфигурация расширения mqseries для PHP 7.4–8.5.
PHP_ARG_WITH([mqseries], [поддержка IBM MQ],
  [AS_HELP_STRING([--with-mqseries[=DIR]], [включить mqseries; DIR — корень IBM MQ])])
PHP_ARG_WITH([mqseries-lib], [тип библиотеки IBM MQ],
  [AS_HELP_STRING([--with-mqseries-lib=mqic|mqm], [клиентская mqic (по умолчанию) или серверная mqm])], [no], [no])

if test "$PHP_MQSERIES" != "no"; then
  AC_MSG_CHECKING([for IBM MQ headers])
  MQSERIES_DIR=""
  MQSERIES_INCDIR=""
  if test "$PHP_MQSERIES" != "yes"; then
    MQSERIES_PATHS="$PHP_MQSERIES"
  else
    MQSERIES_PATHS="/opt/mqm /usr/local /usr"
  fi
  for mq_root in $MQSERIES_PATHS; do
    for mq_inc in inc include; do
      if test -r "$mq_root/$mq_inc/cmqc.h" && test -r "$mq_root/$mq_inc/cmqcfc.h" && test -r "$mq_root/$mq_inc/cmqbc.h" && test -r "$mq_root/$mq_inc/cmqxc.h"; then
        MQSERIES_DIR="$mq_root"
        MQSERIES_INCDIR="$mq_root/$mq_inc"
        break 2
      fi
    done
  done
  if test -z "$MQSERIES_DIR"; then
    AC_MSG_RESULT([not found])
    AC_MSG_ERROR([IBM MQ headers (cmqc.h, cmqcfc.h, cmqbc.h, cmqxc.h) not found; use --with-mqseries=DIR])
  fi
  AC_MSG_RESULT([$MQSERIES_INCDIR])
  PHP_ADD_INCLUDE([$MQSERIES_INCDIR])

  if test "$PHP_MQSERIES_LIB" = "no"; then
    PHP_MQSERIES_LIB="mqic"
  fi
  case "$PHP_MQSERIES_LIB" in
    mqic|mqm) ;;
    *) AC_MSG_ERROR([--with-mqseries-lib accepts only mqic or mqm]) ;;
  esac

  AC_MSG_CHECKING([for IBM MQ $PHP_MQSERIES_LIB library])
  MQSERIES_LIBDIR=""
  MQSERIES_LINK_LIB="$PHP_MQSERIES_LIB"
  if test "$PHP_MQSERIES_LIB" = "mqm"; then
    MQSERIES_LIB_CANDIDATES="mqm_r mqm"
  else
    MQSERIES_LIB_CANDIDATES="mqic"
  fi
  for mq_candidate in $MQSERIES_LIB_CANDIDATES; do
    for mq_libdir in "$PHP_LIBDIR" lib64 lib; do
      if test -f "$MQSERIES_DIR/$mq_libdir/lib$mq_candidate.so" || test -f "$MQSERIES_DIR/$mq_libdir/lib$mq_candidate.a"; then
        dnl AC_CHECK_LIB кэширует ответ по имени библиотеки, но здесь меняется путь.
        eval "unset ac_cv_lib_${mq_candidate}_MQCONN"
        PHP_CHECK_LIBRARY([$mq_candidate], [MQCONN], [
          MQSERIES_LIBDIR="$MQSERIES_DIR/$mq_libdir"
          MQSERIES_LINK_LIB="$mq_candidate"
        ], [], [-L$MQSERIES_DIR/$mq_libdir])
        if test -n "$MQSERIES_LIBDIR"; then
          break 2
        fi
      fi
    done
  done
  if test -z "$MQSERIES_LIBDIR"; then
    AC_MSG_RESULT([not found])
    AC_MSG_ERROR([IBM MQ library with MQCONN not found; check --with-mqseries=DIR and --with-libdir=lib64])
  fi
  AC_MSG_RESULT([$MQSERIES_LIBDIR (lib$MQSERIES_LINK_LIB)])

  PHP_ADD_LIBRARY_WITH_PATH([$MQSERIES_LINK_LIB], [$MQSERIES_LIBDIR], [MQSERIES_SHARED_LIBADD])
  AC_DEFINE([HAVE_MQSERIESLIB], [1], [IBM MQ library is available])

  PHP_CHECK_LIBRARY([$MQSERIES_LINK_LIB], [MQSUB], [
    AC_DEFINE([HAVE_MQSERIESLIB_V7], [1], [IBM MQ publish/subscribe is available])
  ], [AC_MSG_NOTICE([IBM MQ publish/subscribe is not available])], [-L$MQSERIES_LIBDIR])

  PHP_SUBST([MQSERIES_SHARED_LIBADD])
  PHP_NEW_EXTENSION([mqseries], [mqseries.c mqseries_helper.c], [$ext_shared])
fi
