<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
 * Правило автоматического квитования.
 *
 * @property int $id
 * @property int $company_id
 * @property int|null $pool_id Legacy-поле для совместимости со старой схемой
 * @property string $name
 * @property string $section
 * @property string $pair_type
 * @property bool $match_dc
 * @property bool $match_amount
 * @property bool $match_value_date
 * @property bool $match_instruction_id
 * @property bool $match_end_to_end_id
 * @property bool $match_transaction_id
 * @property bool $match_message_id
 * @property bool $cross_id_search
 * @property bool $is_active
 * @property int $priority
 * @property string|null $description
 * @property string $created_at
 * @property string $updated_at
 */
class MatchingRule extends ActiveRecord
{
    /** @var int[] Список ностро-банков правила; пусто = общее правило. */
    public array $pool_ids = [];

    public const SECTION_NRE = 'NRE';
    public const SECTION_INV = 'INV';

    public const PAIR_LS = 'LS';
    public const PAIR_LL = 'LL';
    public const PAIR_SS = 'SS';

    public static function tableName(): string
    {
        return '{{%matching_rules}}';
    }

    public function rules(): array
    {
        return [
            [['company_id', 'name', 'section', 'pair_type'], 'required'],
            [['company_id', 'priority', 'pool_id'], 'integer'],
            [['pool_id'], 'default', 'value' => null],
            [['pool_ids'], 'default', 'value' => []],
            [['pool_ids'], 'each', 'rule' => ['integer']],
            [['pool_ids'], 'validatePoolIds'],
            [['section'], 'in', 'range' => [self::SECTION_NRE, self::SECTION_INV]],
            [['pair_type'], 'in', 'range' => [self::PAIR_LS, self::PAIR_LL, self::PAIR_SS]],
            [[
                'match_dc',
                'match_amount',
                'match_value_date',
                'match_instruction_id',
                'match_end_to_end_id',
                'match_transaction_id',
                'match_message_id',
                'cross_id_search',
                'is_active',
            ], 'boolean'],
            [['name'], 'string', 'max' => 100],
            [['description'], 'string'],
        ];
    }

    public function attributeLabels(): array
    {
        return [
            'id' => 'ID',
            'name' => 'Название правила',
            'pool_id' => 'Ностро-банк',
            'pool_ids' => 'Ностро-банки',
            'section' => 'Раздел',
            'pair_type' => 'Тип пары',
            'match_dc' => 'Противоположный Дебет/Кредит',
            'match_amount' => 'Совпадение суммы',
            'match_value_date' => 'Совпадение даты валютирования',
            'match_instruction_id' => 'Instruction ID',
            'match_end_to_end_id' => 'EndToEnd ID',
            'match_transaction_id' => 'Transaction ID',
            'match_message_id' => 'Message ID',
            'cross_id_search' => 'Перекрёстный поиск ID',
            'is_active' => 'Активно',
            'priority' => 'Приоритет',
            'description' => 'Описание',
        ];
    }

    public function beforeValidate(): bool
    {
        if (!parent::beforeValidate()) {
            return false;
        }

        $this->normalizePoolIds();

        if (empty($this->pool_ids) && $this->pool_id) {
            $this->pool_ids = [(int) $this->pool_id];
        }

        return true;
    }

    public function beforeSave($insert): bool
    {
        if (!parent::beforeSave($insert)) {
            return false;
        }

        $this->normalizePoolIds();
        $this->pool_id = !empty($this->pool_ids) ? (int) $this->pool_ids[0] : null;
        $this->updated_at = date('Y-m-d H:i:s');
        if ($insert) {
            $this->created_at = date('Y-m-d H:i:s');
        }

        return true;
    }

    public function afterFind(): void
    {
        parent::afterFind();

        $this->pool_ids = array_map('intval', Yii::$app->db->createCommand(
            'SELECT pool_id FROM {{%matching_rule_pools}} WHERE rule_id = :ruleId ORDER BY pool_id',
            [':ruleId' => $this->id]
        )->queryColumn());

        if (empty($this->pool_ids) && $this->pool_id) {
            $this->pool_ids = [(int) $this->pool_id];
        }
    }

    public function afterSave($insert, $changedAttributes): void
    {
        parent::afterSave($insert, $changedAttributes);
        $this->syncPoolAssignments();
    }

    public static function sectionList(): array
    {
        return [
            self::SECTION_NRE => 'NRE',
            self::SECTION_INV => 'INV',
        ];
    }

    public static function pairTypeList(): array
    {
        return [
            self::PAIR_LS => 'Ledger ↔ Statement',
            self::PAIR_LL => 'Ledger ↔ Ledger',
            self::PAIR_SS => 'Statement ↔ Statement',
        ];
    }

    public function getCompany()
    {
        return $this->hasOne(Company::class, ['id' => 'company_id']);
    }

    public function getPool()
    {
        return $this->hasOne(AccountPool::class, ['id' => 'pool_id']);
    }

    public function getPools()
    {
        return $this->hasMany(AccountPool::class, ['id' => 'pool_id'])
            ->viaTable('{{%matching_rule_pools}}', ['rule_id' => 'id']);
    }

    public function getConditionsSummary(): string
    {
        $parts = [];
        if ($this->match_dc) {
            $parts[] = 'D/C';
        }
        if ($this->match_amount) {
            $parts[] = 'Сумма';
        }
        if ($this->match_value_date) {
            $parts[] = 'Дата';
        }
        if ($this->match_instruction_id) {
            $parts[] = 'Instruction';
        }
        if ($this->match_end_to_end_id) {
            $parts[] = 'EndToEnd';
        }
        if ($this->match_transaction_id) {
            $parts[] = 'Transaction';
        }
        if ($this->match_message_id) {
            $parts[] = 'Message';
        }
        if ($this->cross_id_search) {
            $parts[] = 'Перекрёстный';
        }

        return implode(', ', $parts) ?: '—';
    }

    /**
     * @return int[]
     */
    public function getEffectivePoolIds(): array
    {
        $this->normalizePoolIds();
        if (!empty($this->pool_ids)) {
            return $this->pool_ids;
        }

        return $this->pool_id ? [(int) $this->pool_id] : [];
    }

    /**
     * @return string[]
     */
    public function getPoolNames(): array
    {
        $ids = $this->getEffectivePoolIds();
        if (empty($ids)) {
            return [];
        }

        $namesById = AccountPool::find()
            ->select(['name', 'id'])
            ->where(['company_id' => $this->company_id, 'id' => $ids])
            ->indexBy('id')
            ->column();

        $result = [];
        foreach ($ids as $id) {
            if (isset($namesById[$id])) {
                $result[] = $namesById[$id];
            }
        }

        return $result;
    }

    public function validatePoolIds(string $attribute): void
    {
        $this->normalizePoolIds();
        if (empty($this->pool_ids)) {
            return;
        }

        $count = (int) AccountPool::find()
            ->where(['company_id' => $this->company_id, 'id' => $this->pool_ids])
            ->count();

        if ($count !== count($this->pool_ids)) {
            $this->addError($attribute, 'Один или несколько выбранных ностро-банков не найдены в этой компании');
        }
    }

    private function normalizePoolIds(): void
    {
        $raw = $this->pool_ids;
        if (!is_array($raw)) {
            $raw = ($raw === null || $raw === '') ? [] : [$raw];
        }

        $poolIds = [];
        foreach ($raw as $value) {
            if ($value === null || $value === '' || (int) $value === 0) {
                continue;
            }
            $poolIds[] = (int) $value;
        }

        $poolIds = array_values(array_unique($poolIds));
        sort($poolIds);
        $this->pool_ids = $poolIds;
    }

    private function syncPoolAssignments(): void
    {
        $poolIds = $this->getEffectivePoolIds();

        Yii::$app->db->createCommand()
            ->delete('{{%matching_rule_pools}}', ['rule_id' => $this->id])
            ->execute();

        if (empty($poolIds)) {
            return;
        }

        $rows = [];
        foreach ($poolIds as $poolId) {
            $rows[] = [$this->id, $poolId];
        }

        Yii::$app->db->createCommand()
            ->batchInsert('{{%matching_rule_pools}}', ['rule_id', 'pool_id'], $rows)
            ->execute();
    }
}
